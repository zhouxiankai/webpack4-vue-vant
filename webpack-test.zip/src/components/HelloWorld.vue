<template>
    <div class='hello-index'>
        hello world!123112451
        <div class="aa">less</div>
        <img src="/static/images/icon.png">
    </div>
</template>

<script>
export default {
    data () {
        return {

        }
    },
    mounted() {
        this.fn()
    },
    methods: {
        fn() {
            let arr = [1,2,3]
            for(let item of arr){
                console.log(item)
            }
        }
    },
    components: {

    }
}
</script>

<style lang='less'>
.hello-index{font-size:30px;
    .aa{color:red;}
}
</style>
