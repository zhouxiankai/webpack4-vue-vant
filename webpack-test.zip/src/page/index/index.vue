<template>
    <div class=''>
        hello world!
    </div>
</template>

<script>
export default {
    data () {
        return {

        }
    },
    mounted: {

    },
    methods: {

    },
    components: {

    }
}
</script>

<style lang='less'>

</style>


